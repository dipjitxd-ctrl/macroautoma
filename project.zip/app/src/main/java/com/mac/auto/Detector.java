package com.mac.auto;

public class Detector {

    public static class Blob {
        public float cx;
        public float cy;
        public int w;
        public int h;
        public int cells;
        public float meanDist;
        public int minX;
        public int maxX;
        public int minY;
        public int maxY;
    }

    public static final int MODE_BG = 0;
    public static final int MODE_DARK = 1;

    // Most common colour on screen = the game background (handles yellow, purple...).
    public static int background(Grid g) {
        int[] cnt = new int[512];
        long[] sr = new long[512];
        long[] sg = new long[512];
        long[] sb = new long[512];
        for (int i = 0; i < g.px.length; i += 3) {
            int p = g.px[i];
            int r = (p >> 16) & 0xFF;
            int gr = (p >> 8) & 0xFF;
            int b = p & 0xFF;
            int k = ((r >> 5) << 6) | ((gr >> 5) << 3) | (b >> 5);
            cnt[k]++;
            sr[k] += r;
            sg[k] += gr;
            sb[k] += b;
        }
        int best = 0;
        for (int k = 1; k < 512; k++) {
            if (cnt[k] > cnt[best]) {
                best = k;
            }
        }
        if (cnt[best] == 0) {
            return 0xFFFFFFFF;
        }
        int r = (int) (sr[best] / cnt[best]);
        int gr = (int) (sg[best] / cnt[best]);
        int b = (int) (sb[best] / cnt[best]);
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    public static int dist(int p, int bg) {
        int dr = Math.abs(((p >> 16) & 0xFF) - ((bg >> 16) & 0xFF));
        int dg = Math.abs(((p >> 8) & 0xFF) - ((bg >> 8) & 0xFF));
        int db = Math.abs((p & 0xFF) - (bg & 0xFF));
        return dr + dg + db;
    }

    // Finds connected blobs. yTop / yBottom are in real pixels.
    public static Blob[] blobs(Grid g, int mode, int bg, int thr, int yTop, int yBottom) {
        int gw = g.gw;
        int gh = g.gh;
        int y0 = Math.max(0, yTop / g.step);
        int y1 = Math.min(gh, yBottom / g.step);
        boolean[] mask = new boolean[gw * gh];
        int[] dd = new int[gw * gh];
        for (int y = y0; y < y1; y++) {
            for (int x = 0; x < gw; x++) {
                int p = g.px[y * gw + x];
                if (mode == MODE_BG) {
                    int d = dist(p, bg);
                    if (d > thr) {
                        mask[y * gw + x] = true;
                        dd[y * gw + x] = d;
                    }
                } else {
                    int s = ((p >> 16) & 0xFF) + ((p >> 8) & 0xFF) + (p & 0xFF);
                    if (s < thr) {
                        mask[y * gw + x] = true;
                        dd[y * gw + x] = 765 - s;
                    }
                }
            }
        }
        Blob[] out = new Blob[24];
        int n = 0;
        int[] stack = new int[gw * gh];
        for (int y = y0; y < y1; y++) {
            for (int x = 0; x < gw; x++) {
                int idx = y * gw + x;
                if (!mask[idx]) {
                    continue;
                }
                int sp = 0;
                stack[sp++] = idx;
                mask[idx] = false;
                long sx = 0;
                long sy = 0;
                long sd = 0;
                int cells = 0;
                int minX = x;
                int maxX = x;
                int minY = y;
                int maxY = y;
                while (sp > 0) {
                    int c = stack[--sp];
                    int cx = c % gw;
                    int cy = c / gw;
                    sx += cx;
                    sy += cy;
                    sd += dd[c];
                    cells++;
                    if (cx < minX) minX = cx;
                    if (cx > maxX) maxX = cx;
                    if (cy < minY) minY = cy;
                    if (cy > maxY) maxY = cy;
                    if (cx + 1 < gw && mask[c + 1]) {
                        mask[c + 1] = false;
                        stack[sp++] = c + 1;
                    }
                    if (cx - 1 >= 0 && mask[c - 1]) {
                        mask[c - 1] = false;
                        stack[sp++] = c - 1;
                    }
                    if (cy + 1 < gh && mask[c + gw]) {
                        mask[c + gw] = false;
                        stack[sp++] = c + gw;
                    }
                    if (cy - 1 >= 0 && mask[c - gw]) {
                        mask[c - gw] = false;
                        stack[sp++] = c - gw;
                    }
                }
                if (cells < 2) {
                    continue;
                }
                if (n >= out.length) {
                    return out;
                }
                Blob b = new Blob();
                b.cx = ((float) sx / cells + 0.5f) * g.step;
                b.cy = ((float) sy / cells + 0.5f) * g.step;
                b.w = (maxX - minX + 1) * g.step;
                b.h = (maxY - minY + 1) * g.step;
                b.cells = cells;
                b.meanDist = (float) sd / cells;
                b.minX = minX * g.step;
                b.maxX = (maxX + 1) * g.step;
                b.minY = minY * g.step;
                b.maxY = (maxY + 1) * g.step;
                out[n++] = b;
            }
        }
        Blob[] res = new Blob[n];
        for (int i = 0; i < n; i++) {
            res[i] = out[i];
        }
        return res;
    }

    // Picks the blob that best matches the emoji size (ew, eh in px; 0 = unknown).
    public static Blob pickBall(Blob[] bl, int ew, int eh, int screenW) {
        Blob best = null;
        float bestScore = 1e9f;
        for (int i = 0; i < bl.length; i++) {
            Blob b = bl[i];
            int maxSide = Math.max(b.w, b.h);
            if (ew > 0) {
                float ref = Math.max(ew, eh);
                if (maxSide < ref * 0.45f || maxSide > ref * 2.2f) {
                    continue;
                }
                float score = Math.abs(maxSide - ref);
                if (score < bestScore) {
                    bestScore = score;
                    best = b;
                }
            } else {
                if (maxSide < screenW * 0.025f || maxSide > screenW * 0.22f) {
                    continue;
                }
                float score = -b.meanDist * b.cells;
                if (score < bestScore) {
                    bestScore = score;
                    best = b;
                }
            }
        }
        return best;
    }

    // Finds the black pill-shaped paddle in the lower half of the screen.
    public static Blob findPaddle(Grid g) {
        Blob[] bl = blobs(g, MODE_DARK, 0, 120, g.h / 2, g.h);
        Blob best = null;
        for (int i = 0; i < bl.length; i++) {
            Blob b = bl[i];
            if (b.w >= b.h * 2 && b.w > g.w * 0.10f) {
                if (best == null || b.w * b.h > best.w * best.h) {
                    best = b;
                }
            }
        }
        return best;
    }
}
