package com.mac.auto;

import android.graphics.Bitmap;

import java.nio.ByteBuffer;

// A coarse sampled copy of a frame (every "step" pixels). Cheap to scan every frame.
public class Grid {

    public int[] px;
    public int gw;
    public int gh;
    public int step;
    public int w;
    public int h;

    public static Grid fromBuffer(ByteBuffer b, int rowStride, int pixStride, int w, int h, int step) {
        Grid g = new Grid();
        g.step = step;
        g.w = w;
        g.h = h;
        g.gw = w / step;
        g.gh = h / step;
        g.px = new int[g.gw * g.gh];
        for (int gy = 0; gy < g.gh; gy++) {
            int rowBase = gy * step * rowStride;
            for (int gx = 0; gx < g.gw; gx++) {
                int i = rowBase + gx * step * pixStride;
                int r = b.get(i) & 0xFF;
                int gr = b.get(i + 1) & 0xFF;
                int bl = b.get(i + 2) & 0xFF;
                g.px[gy * g.gw + gx] = 0xFF000000 | (r << 16) | (gr << 8) | bl;
            }
        }
        return g;
    }

    public static Grid fromBitmap(Bitmap bmp, int stepOfOriginal, int originalW, int originalH) {
        // bmp may be scaled down; step is expressed in original pixels
        Grid g = new Grid();
        g.step = stepOfOriginal;
        g.w = originalW;
        g.h = originalH;
        g.gw = originalW / stepOfOriginal;
        g.gh = originalH / stepOfOriginal;
        g.px = new int[g.gw * g.gh];
        float sx = (float) bmp.getWidth() / originalW;
        float sy = (float) bmp.getHeight() / originalH;
        for (int gy = 0; gy < g.gh; gy++) {
            int by = Math.min(bmp.getHeight() - 1, (int) (gy * stepOfOriginal * sy));
            for (int gx = 0; gx < g.gw; gx++) {
                int bx = Math.min(bmp.getWidth() - 1, (int) (gx * stepOfOriginal * sx));
                g.px[gy * g.gw + gx] = bmp.getPixel(bx, by);
            }
        }
        return g;
    }
}
