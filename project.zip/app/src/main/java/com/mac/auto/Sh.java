package com.mac.auto;

import android.content.pm.PackageManager;

import java.io.OutputStream;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

// Shizuku helper: live status + fast touch injection through one persistent shell.
public class Sh {

    private static Process proc;
    private static OutputStream out;

    // 0 = not running, 1 = running but no permission, 2 = ready
    public static int state() {
        try {
            if (!Shizuku.pingBinder()) {
                return 0;
            }
            if (Shizuku.isPreV11()) {
                return 0;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                return 2;
            }
            return 1;
        } catch (Throwable t) {
            return 0;
        }
    }

    public static boolean ready() {
        return state() == 2;
    }

    public static void requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(4242);
            }
        } catch (Throwable t) {
            // ignore
        }
    }

    private static synchronized boolean ensureShell() {
        if (proc != null) {
            try {
                proc.exitValue();
                proc = null;
                out = null;
            } catch (IllegalThreadStateException e) {
                return true;
            }
        }
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            proc = (Process) m.invoke(null, new Object[] {new String[] {"sh"}, null, null});
            out = proc.getOutputStream();
            return true;
        } catch (Throwable t) {
            proc = null;
            out = null;
            return false;
        }
    }

    public static synchronized boolean run(String cmd) {
        if (!ensureShell()) {
            return false;
        }
        try {
            out.write((cmd + "\n").getBytes());
            out.flush();
            return true;
        } catch (Throwable t) {
            proc = null;
            out = null;
            return false;
        }
    }

    public static void swipe(int x1, int y1, int x2, int y2, int durMs) {
        run("input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + durMs);
    }

    public static void tap(int x, int y) {
        run("input tap " + x + " " + y);
    }

    public static synchronized void close() {
        try {
            if (proc != null) {
                proc.destroy();
            }
        } catch (Throwable t) {
            // ignore
        }
        proc = null;
        out = null;
    }
}
