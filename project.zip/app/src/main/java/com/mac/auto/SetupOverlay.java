package com.mac.auto;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.widget.FrameLayout;

// Full-screen editor drawn on a frozen screenshot. Mode TRACE edits the slider, mode TARGET edits the green ball.
public class SetupOverlay extends FrameLayout {

    public static final int TRACE = 0;
    public static final int TARGET = 1;

    public int mode;
    public Bitmap frozen;
    public float lx;
    public float rx;
    public float ly;
    public float redX;
    public float gx;
    public float gy;
    public RectF found = null;

    private int sw;
    private int sh;
    private int active = 0; // 1 left, 2 right, 3 red, 4 green
    private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private RectF dst = new RectF();
    private float ballR;

    public SetupOverlay(Context c, int mode, int screenW, int screenH) {
        super(c);
        this.mode = mode;
        this.sw = screenW;
        this.sh = screenH;
        ballR = Ui.dp(c, 24);
        setWillNotDraw(false);
    }

    private float touchR() {
        return Ui.dp(getContext(), 46);
    }

    @Override
    protected void onDraw(Canvas c) {
        float vw = getWidth();
        float vh = getHeight();
        if (frozen != null) {
            dst.set(0, 0, vw, vh);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            c.drawBitmap(frozen, null, dst, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.alpha(0xFF000000, frozen != null ? 120 : 150));
        c.drawRect(0, 0, vw, vh, p);

        float k = vw / sw;
        if (mode == TRACE) {
            float y = ly * k;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(Ui.dp(getContext(), 10));
            p.setColor(Ui.alpha(Ui.BLUE, 70));
            c.drawLine(lx * k, y, rx * k, y, p);
            p.setStrokeWidth(Ui.dp(getContext(), 3));
            p.setColor(Ui.BLUE);
            c.drawLine(lx * k, y, rx * k, y, p);
            ball(c, lx * k, y, Ui.BLUE, active == 1);
            ball(c, rx * k, y, Ui.BLUE, active == 2);
            ball(c, redX * k, y, Ui.RED, active == 3);
        } else {
            if (found != null) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Ui.dp(getContext(), 2));
                p.setColor(Ui.alpha(Ui.GOOD, 200));
                c.drawRoundRect(new RectF(found.left * k, found.top * k, found.right * k, found.bottom * k),
                        Ui.dp(getContext(), 8), Ui.dp(getContext(), 8), p);
            }
            ball(c, gx * k, gy * k, Ui.GOOD, active == 4);
        }
    }

    private void ball(Canvas c, float x, float y, int color, boolean on) {
        float r = ballR * (on ? 1.2f : 1f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(Ui.alpha(color, 128));
        c.drawCircle(x, y, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Ui.dp(getContext(), 2.5f));
        p.setColor(color);
        c.drawCircle(x, y, r, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(x, y, Ui.dp(getContext(), 2.5f), p);
    }

    private boolean near(float x, float y, float bx, float by) {
        float dx = x - bx;
        float dy = y - by;
        return dx * dx + dy * dy < touchR() * touchR();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float k = (float) sw / getWidth();
        float x = e.getX() * k;
        float y = e.getY() * k;
        int a = e.getAction();
        if (a == MotionEvent.ACTION_DOWN) {
            active = 0;
            float kk = 1f / k;
            float tx = e.getX();
            float ty = e.getY();
            if (mode == TRACE) {
                if (near(tx, ty, redX * kk, ly * kk)) {
                    active = 3;
                } else if (near(tx, ty, lx * kk, ly * kk)) {
                    active = 1;
                } else if (near(tx, ty, rx * kk, ly * kk)) {
                    active = 2;
                }
            } else {
                // easy mode: grab the green ball from anywhere, it jumps to the finger
                active = 4;
                gx = x;
                gy = y;
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            float margin = ballR / (float) getWidth() * sw;
            if (active == 1) {
                lx = Math.max(margin, Math.min(x, rx - margin * 2));
                ly = clampY(y);
                if (redX < lx) redX = lx;
            } else if (active == 2) {
                rx = Math.min(sw - margin, Math.max(x, lx + margin * 2));
                ly = clampY(y);
                if (redX > rx) redX = rx;
            } else if (active == 3) {
                redX = Math.max(lx, Math.min(x, rx));
            } else if (active == 4) {
                gx = x;
                gy = y;
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            active = 0;
            invalidate();
            return true;
        }
        return true;
    }

    private float clampY(float y) {
        return Math.max(sh * 0.3f, Math.min(y, sh - 20));
    }
}
