package com.mac.auto;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

// Round glass button with a hand-drawn icon (no image files needed).
public class IconView extends View {

    public static final int LOGO = 0;
    public static final int TRACE = 1;
    public static final int TARGET = 2;
    public static final int PLAY = 3;
    public static final int STOP = 4;
    public static final int CLOSE = 5;

    private int type;
    private int ring = Ui.ACCENT;
    private int fill = Ui.alpha(Ui.CARD, 235);
    private Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Path path = new Path();
    private RectF rect = new RectF();

    public IconView(Context c, int type) {
        super(c);
        this.type = type;
    }

    public void setType(int t) {
        type = t;
        invalidate();
    }

    public void setRing(int color) {
        ring = color;
        invalidate();
    }

    public void setFill(int color) {
        fill = color;
        invalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getAction();
        if (a == MotionEvent.ACTION_DOWN) {
            animate().scaleX(0.9f).scaleY(0.9f).setDuration(80).start();
        } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            animate().scaleX(1f).scaleY(1f).setDuration(120).start();
        }
        return super.onTouchEvent(e);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;
        float r = Math.min(w, h) / 2f - Ui.dp(getContext(), 3);

        // soft glow
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, Math.min(w, h) / 2f,
                new int[] {Ui.alpha(ring, 90), Ui.alpha(ring, 0)}, new float[] {0.6f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, Math.min(w, h) / 2f, p);
        p.setShader(null);

        p.setColor(fill);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Ui.dp(getContext(), 2));
        p.setColor(ring);
        c.drawCircle(cx, cy, r, p);

        float s = r * 0.5f;
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(Ui.dp(getContext(), 2.2f));
        p.setColor(Ui.TEXT);
        p.setStyle(Paint.Style.STROKE);

        if (type == LOGO) {
            // stylised paddle + ball
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.TEXT);
            rect.set(cx - s, cy + s * 0.45f, cx + s, cy + s * 0.95f);
            c.drawRoundRect(rect, s, s, p);
            p.setColor(Ui.ACCENT2);
            c.drawCircle(cx + s * 0.35f, cy - s * 0.35f, s * 0.38f, p);
        } else if (type == TRACE) {
            c.drawLine(cx - s, cy, cx + s, cy, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.BLUE);
            c.drawCircle(cx - s, cy, s * 0.32f, p);
            c.drawCircle(cx + s, cy, s * 0.32f, p);
            p.setColor(Ui.RED);
            c.drawCircle(cx + s * 0.1f, cy, s * 0.28f, p);
        } else if (type == TARGET) {
            c.drawCircle(cx, cy, s * 0.8f, p);
            c.drawLine(cx, cy - s * 1.1f, cx, cy - s * 0.45f, p);
            c.drawLine(cx, cy + s * 0.45f, cx, cy + s * 1.1f, p);
            c.drawLine(cx - s * 1.1f, cy, cx - s * 0.45f, cy, p);
            c.drawLine(cx + s * 0.45f, cy, cx + s * 1.1f, cy, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.GOOD);
            c.drawCircle(cx, cy, s * 0.22f, p);
        } else if (type == PLAY) {
            path.reset();
            path.moveTo(cx - s * 0.6f, cy - s * 0.85f);
            path.lineTo(cx + s * 0.9f, cy);
            path.lineTo(cx - s * 0.6f, cy + s * 0.85f);
            path.close();
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.GOOD);
            c.drawPath(path, p);
        } else if (type == STOP) {
            p.setStyle(Paint.Style.FILL);
            p.setColor(Ui.BAD);
            rect.set(cx - s * 0.7f, cy - s * 0.7f, cx + s * 0.7f, cy + s * 0.7f);
            c.drawRoundRect(rect, s * 0.2f, s * 0.2f, p);
        } else if (type == CLOSE) {
            p.setColor(Ui.BAD);
            c.drawLine(cx - s * 0.7f, cy - s * 0.7f, cx + s * 0.7f, cy + s * 0.7f, p);
            c.drawLine(cx + s * 0.7f, cy - s * 0.7f, cx - s * 0.7f, cy + s * 0.7f, p);
        }
    }
}
