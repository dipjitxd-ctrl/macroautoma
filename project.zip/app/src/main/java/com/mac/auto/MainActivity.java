package com.mac.auto;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private static final int REQ_CAPTURE = 77;
    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;
    private static final int MATCH = LinearLayout.LayoutParams.MATCH_PARENT;

    private Handler handler;

    private TextView overlayDot;
    private TextView overlayDesc;
    private TextView overlayBtn;
    private TextView shizukuDot;
    private TextView shizukuDesc;
    private TextView shizukuBtn;
    private TextView captureDot;
    private TextView captureDesc;
    private TextView captureBtn;
    private TextView startBtn;
    private TextView note;

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        if (bold) {
            t.setTypeface(Typeface.DEFAULT_BOLD);
        }
        return t;
    }

    private TextView smallButton(String s) {
        TextView b = text(s, 13, 0xFF0B0D12, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(16), dp(9), dp(16), dp(9));
        b.setBackground(Ui.rounded(this, Ui.ACCENT2, 18, 0, 0));
        return b;
    }

    // Builds one step card and returns the three live views through the holder arrays
    private TextView[] stepCard(LinearLayout parent, String title, String firstDesc, String btnText) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        card.setBackground(Ui.rounded(this, Ui.CARD, 20, Ui.CARD_STROKE, 1));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(MATCH, WRAP);
        cp.bottomMargin = dp(12);
        card.setLayoutParams(cp);

        TextView dot = text("\u25CF", 22, Ui.WARN, false);
        dot.setLayoutParams(new LinearLayout.LayoutParams(dp(34), WRAP));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(0, WRAP, 1f);
        mid.setLayoutParams(mp);
        TextView t = text(title, 16, Ui.TEXT, true);
        TextView d = text(firstDesc, 13, Ui.SUB, false);
        mid.addView(t);
        mid.addView(d);

        TextView b = smallButton(btnText);
        card.addView(dot);
        card.addView(mid);
        card.addView(b);
        parent.addView(card);
        return new TextView[] {dot, d, b};
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        handler = new Handler(Looper.getMainLooper());
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Ui.BG);
        scroll.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(56), dp(22), dp(28));
        scroll.addView(root);

        TextView title = text("MacroAutoma", 32, Ui.TEXT, true);
        TextView sub = text("Emoji ping pong auto player", 14, Ui.SUB, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(WRAP, WRAP);
        sp.bottomMargin = dp(30);
        sub.setLayoutParams(sp);
        root.addView(title);
        root.addView(sub);

        TextView[] a = stepCard(root, "Overlay", "Lets the Float button sit above other apps", "Allow");
        overlayDot = a[0];
        overlayDesc = a[1];
        overlayBtn = a[2];
        TextView[] b = stepCard(root, "Shizuku", "Checking...", "Allow");
        shizukuDot = b[0];
        shizukuDesc = b[1];
        shizukuBtn = b[2];
        TextView[] c = stepCard(root, "Screen reading", "Lets the app watch the game", "Allow");
        captureDot = c[0];
        captureDesc = c[1];
        captureBtn = c[2];

        note = text("", 13, Ui.WARN, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(MATCH, WRAP);
        np.topMargin = dp(8);
        np.bottomMargin = dp(8);
        note.setLayoutParams(np);
        root.addView(note);

        View spacer = new View(this);
        spacer.setLayoutParams(new LinearLayout.LayoutParams(MATCH, 0, 1f));
        root.addView(spacer);

        startBtn = text("Start Float", 17, 0xFF0B0D12, true);
        startBtn.setGravity(Gravity.CENTER);
        startBtn.setPadding(dp(20), dp(17), dp(20), dp(17));
        startBtn.setBackground(Ui.gradient(this, Ui.ACCENT2, Ui.GOOD, 30));
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(MATCH, WRAP);
        stp.topMargin = dp(12);
        startBtn.setLayoutParams(stp);
        root.addView(startBtn);

        TextView how = text("", 12, Ui.SUB, false);
        how.setText("Float menu: Trace Map  \u2022  Set Screen  \u2022  Play");
        how.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(MATCH, WRAP);
        hp.topMargin = dp(14);
        how.setLayoutParams(hp);
        root.addView(how);

        setContentView(scroll);

        overlayBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivity(i);
            }
        });

        shizukuBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int st = Sh.state();
                if (st == 1) {
                    Sh.requestPermission();
                } else if (st == 0) {
                    Intent li = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                    if (li != null) {
                        startActivity(li);
                    } else {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")));
                    }
                }
            }
        });

        captureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MediaProjectionManager m = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(m.createScreenCaptureIntent(), REQ_CAPTURE);
            }
        });

        startBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onStart_();
            }
        });

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {"android.permission.POST_NOTIFICATIONS"}, 5);
        }
    }

    private void onStart_() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow overlay first", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!ScreenTrackerService.ready) {
            Toast.makeText(this, "Allow screen reading first", Toast.LENGTH_SHORT).show();
            return;
        }
        startService(new Intent(this, FloatingService.class));
        if (Sh.ready()) {
            Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME);
            home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(home);
        } else {
            note.setText("Float is on. Start Shizuku (and allow it here), then you can go home.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_CAPTURE) {
            if (res == RESULT_OK && data != null) {
                Intent i = new Intent(this, ScreenTrackerService.class);
                i.setAction(ScreenTrackerService.ACTION_INIT);
                i.putExtra("rc", res);
                i.putExtra("data", data);
                if (Build.VERSION.SDK_INT >= 26) {
                    startForegroundService(i);
                } else {
                    startService(i);
                }
            } else {
                Toast.makeText(this, "Screen reading was not allowed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(refresh);
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(refresh);
    }

    private void setStep(TextView dot, TextView desc, TextView btn, int color, String d, String btnText) {
        dot.setTextColor(color);
        desc.setText(d);
        if (btnText == null) {
            btn.setVisibility(View.GONE);
        } else {
            btn.setVisibility(View.VISIBLE);
            btn.setText(btnText);
        }
    }

    private Runnable refresh = new Runnable() {
        @Override
        public void run() {
            boolean ov = Settings.canDrawOverlays(MainActivity.this);
            if (ov) {
                setStep(overlayDot, overlayDesc, overlayBtn, Ui.GOOD, "Granted", null);
            } else {
                setStep(overlayDot, overlayDesc, overlayBtn, Ui.WARN, "Lets the Float button sit above other apps", "Allow");
            }

            int st = Sh.state();
            if (st == 2) {
                setStep(shizukuDot, shizukuDesc, shizukuBtn, Ui.GOOD, "Running and allowed", null);
            } else if (st == 1) {
                setStep(shizukuDot, shizukuDesc, shizukuBtn, Ui.WARN, "Running - needs your permission", "Allow");
            } else {
                setStep(shizukuDot, shizukuDesc, shizukuBtn, Ui.BAD, "Not running - open Shizuku and start it", "Open");
            }

            boolean cap = ScreenTrackerService.ready;
            if (cap) {
                setStep(captureDot, captureDesc, captureBtn, Ui.GOOD, "Active", null);
            } else {
                setStep(captureDot, captureDesc, captureBtn, Ui.WARN, "Lets the app watch the game", "Allow");
            }

            boolean ok = ov && cap;
            startBtn.setAlpha(ok ? 1f : 0.4f);
            if (st == 2 && note.getText().toString().startsWith("Float is on")) {
                note.setText("");
            }
            handler.postDelayed(this, 700);
        }
    };
}
