package com.mac.auto;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;

public class Ui {

    public static final int BG = Color.parseColor("#0B0D12");
    public static final int CARD = Color.parseColor("#151922");
    public static final int CARD_STROKE = Color.parseColor("#232A38");
    public static final int ACCENT = Color.parseColor("#7C5CFF");
    public static final int ACCENT2 = Color.parseColor("#22D3EE");
    public static final int GOOD = Color.parseColor("#34D399");
    public static final int WARN = Color.parseColor("#FBBF24");
    public static final int BAD = Color.parseColor("#F87171");
    public static final int TEXT = Color.parseColor("#F5F7FA");
    public static final int SUB = Color.parseColor("#8A93A6");
    public static final int BLUE = Color.parseColor("#3B82F6");
    public static final int RED = Color.parseColor("#FF4D5E");

    public static int dp(Context c, float v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    public static GradientDrawable rounded(Context c, int fill, float radiusDp, int stroke, float strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(c, radiusDp));
        if (stroke != 0) {
            d.setStroke(dp(c, strokeDp), stroke);
        }
        return d;
    }

    public static GradientDrawable gradient(Context c, int from, int to, float radiusDp) {
        GradientDrawable d = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[] {from, to});
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    public static int alpha(int color, int a) {
        return Color.argb(a, Color.red(color), Color.green(color), Color.blue(color));
    }
}
