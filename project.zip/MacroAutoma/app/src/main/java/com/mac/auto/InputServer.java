package com.mac.auto;

import android.os.SystemClock;
import android.view.InputDevice;
import android.view.InputEvent;
import android.view.MotionEvent;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

// Runs as the shell user (started through Shizuku with app_process).
// Reads lines "D x y", "M x y", "U x y" and injects one continuous touch pointer.
public class InputServer {

    private static Object im;
    private static Method inject2;
    private static Method inject3;

    private static void init() throws Exception {
        Class cls = null;
        try {
            cls = Class.forName("android.hardware.input.InputManagerGlobal");
        } catch (Throwable t) {
            cls = null;
        }
        if (cls == null) {
            cls = Class.forName("android.hardware.input.InputManager");
        }
        Method gi = cls.getDeclaredMethod("getInstance");
        gi.setAccessible(true);
        im = gi.invoke(null);
        try {
            inject2 = cls.getMethod("injectInputEvent", InputEvent.class, int.class);
        } catch (Throwable t) {
            inject2 = null;
        }
        if (inject2 == null) {
            inject3 = cls.getMethod("injectInputEvent", InputEvent.class, int.class, int.class);
        }
    }

    private static void inject(MotionEvent e) throws Exception {
        if (inject2 != null) {
            inject2.invoke(im, e, 0);
        } else {
            inject3.invoke(im, e, 0, -1);
        }
    }

    public static void main(String[] args) {
        try {
            init();
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            System.out.println("ERR init " + c);
            System.out.flush();
            return;
        }
        System.out.println("READY");
        System.out.flush();
        long downTime = 0;
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            String line;
            while ((line = br.readLine()) != null) {
                if (line.length() < 1) {
                    continue;
                }
                char c = line.charAt(0);
                if (c == 'Q') {
                    break;
                }
                if (c != 'D' && c != 'M' && c != 'U') {
                    continue;
                }
                String[] p = line.split(" ");
                if (p.length < 3) {
                    continue;
                }
                float x = Float.parseFloat(p[1]);
                float y = Float.parseFloat(p[2]);
                long now = SystemClock.uptimeMillis();
                int action;
                if (c == 'D') {
                    downTime = now;
                    action = MotionEvent.ACTION_DOWN;
                } else if (c == 'M') {
                    action = MotionEvent.ACTION_MOVE;
                } else {
                    action = MotionEvent.ACTION_UP;
                }
                MotionEvent e = MotionEvent.obtain(downTime, now, action, x, y, 1.0f, 1.0f, 0, 1.0f, 1.0f, 0, 0);
                e.setSource(InputDevice.SOURCE_TOUCHSCREEN);
                try {
                    inject(e);
                } catch (Throwable t) {
                    Throwable cc = t.getCause() != null ? t.getCause() : t;
                    System.out.println("ERR inject " + cc);
                    System.out.flush();
                }
                e.recycle();
            }
        } catch (Throwable t) {
            System.out.println("ERR loop " + t);
            System.out.flush();
        }
    }
}
