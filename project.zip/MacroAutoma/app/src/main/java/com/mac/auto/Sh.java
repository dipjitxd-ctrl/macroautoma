package com.mac.auto;

import android.content.pm.PackageManager;

import java.io.OutputStream;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

// Shizuku helper: live status + fast touch injection through one persistent shell.
public class Sh {

    public static volatile String lastError = "";
    public static volatile int sent = 0;
    private static Process proc;
    private static OutputStream out;

    // 0 = not running, 1 = running but no permission, 2 = ready
    public static int state() {
        try {
            if (!Shizuku.pingBinder()) {
                return 0;
            }
            if (Shizuku.isPreV11()) {
                return 0;
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                return 2;
            }
            return 1;
        } catch (Throwable t) {
            return 0;
        }
    }

    public static boolean ready() {
        return state() == 2;
    }

    public static void requestPermission() {
        try {
            if (Shizuku.pingBinder() && !Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(4242);
            }
        } catch (Throwable t) {
            // ignore
        }
    }

    private static synchronized boolean ensureShell() {
        if (proc != null && out != null) {
            return true;
        }
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            proc = (Process) m.invoke(null, new Object[] {new String[] {"sh"}, null, null});
            out = proc.getOutputStream();
            return true;
        } catch (Throwable t) {
            lastError = "shell: " + t;
            proc = null;
            out = null;
            return false;
        }
    }

    public static synchronized boolean run(String cmd) {
        for (int attempt = 0; attempt < 2; attempt++) {
            if (!ensureShell()) {
                return false;
            }
            try {
                out.write((cmd + "\n").getBytes());
                out.flush();
                sent++;
                return true;
            } catch (Throwable t) {
                lastError = "write: " + t;
                proc = null;
                out = null;
            }
        }
        return false;
    }

    public static void swipe(int x1, int y1, int x2, int y2, int durMs) {
        boolean ok = run("input swipe " + x1 + " " + y1 + " " + x2 + " " + y2 + " " + durMs);
        if (!ok) {
            // fallback: one-off process
            exec(new String[] {"input", "swipe", "" + x1, "" + y1, "" + x2, "" + y2, "" + durMs});
        }
    }

    // One-off command, waits for it and returns "exit=N output"
    public static String exec(String[] cmd) {
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            Process p = (Process) m.invoke(null, new Object[] {cmd, null, null});
            java.io.InputStream is = p.getInputStream();
            java.io.InputStream es = p.getErrorStream();
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[512];
            int n;
            while ((n = is.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            while ((n = es.read(buf)) > 0) {
                bo.write(buf, 0, n);
            }
            int code = p.waitFor();
            String o = bo.toString().trim();
            return "exit=" + code + (o.length() > 0 ? " " + o : "");
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            lastError = "exec: " + c;
            return "FAIL " + c;
        }
    }

    public static String testSwipe(int redX, int left, int right, int y) {
        String a = exec(new String[] {"input", "swipe", "" + redX, "" + y, "" + left, "" + y, "350"});
        String b = exec(new String[] {"input", "swipe", "" + left, "" + y, "" + right, "" + y, "500"});
        return "swipe1 " + a + " | swipe2 " + b;
    }

    public static void tap(int x, int y) {
        run("input tap " + x + " " + y);
    }


    // ---------- continuous touch server (app_process as shell) ----------

    private static Process srvProc;
    private static OutputStream srvOut;
    public static volatile boolean srvReady = false;

    public static boolean startServer(String apkPath) {
        synchronized (Sh.class) {
            if (srvReady && srvProc != null && srvOut != null) {
                return true;
            }
        }
        stopServer();
        try {
            Method m = Shizuku.class.getDeclaredMethod("newProcess",
                    String[].class, String[].class, String.class);
            m.setAccessible(true);
            String[] cmd = new String[] {"app_process", "-Djava.class.path=" + apkPath,
                    "/system/bin", "com.mac.auto.InputServer"};
            Process p = (Process) m.invoke(null, new Object[] {cmd, null, null});
            synchronized (Sh.class) {
                srvProc = p;
                srvOut = p.getOutputStream();
            }
            final java.io.InputStream is = p.getInputStream();
            final java.io.InputStream es = p.getErrorStream();
            srvReady = false;
            Thread t1 = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(is));
                        String l;
                        while ((l = br.readLine()) != null) {
                            if (l.startsWith("READY")) {
                                srvReady = true;
                            } else {
                                lastError = "srv: " + l;
                            }
                        }
                    } catch (Throwable e) {
                        // stream closed
                    }
                    srvReady = false;
                }
            });
            t1.setDaemon(true);
            t1.start();
            Thread t2 = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(es));
                        String l;
                        while ((l = br.readLine()) != null) {
                            if (lastError.length() < 160) {
                                lastError = "srv-err: " + l;
                            }
                        }
                    } catch (Throwable e) {
                        // stream closed
                    }
                }
            });
            t2.setDaemon(true);
            t2.start();
            for (int i = 0; i < 80; i++) {
                if (srvReady) {
                    return true;
                }
                Thread.sleep(50);
            }
        } catch (Throwable t) {
            Throwable c = t.getCause() != null ? t.getCause() : t;
            lastError = "start: " + c;
        }
        stopServer();
        return false;
    }

    public static synchronized boolean touch(char c, int x, int y) {
        if (!srvReady || srvOut == null) {
            return false;
        }
        try {
            srvOut.write((c + " " + x + " " + y + "\n").getBytes());
            srvOut.flush();
            sent++;
            return true;
        } catch (Throwable t) {
            lastError = "touch: " + t;
            srvReady = false;
            return false;
        }
    }

    public static synchronized void stopServer() {
        srvReady = false;
        try {
            if (srvOut != null) {
                srvOut.write("Q\n".getBytes());
                srvOut.flush();
            }
        } catch (Throwable t) {
            // ignore
        }
        try {
            if (srvProc != null) {
                srvProc.destroy();
            }
        } catch (Throwable t) {
            // ignore
        }
        srvProc = null;
        srvOut = null;
    }

    public static synchronized void close() {
        stopServer();
        try {
            if (proc != null) {
                proc.destroy();
            }
        } catch (Throwable t) {
            // ignore
        }
        proc = null;
        out = null;
    }
}
