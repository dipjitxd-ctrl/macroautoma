// ===== GITHUB BUILD V2 =====
package com.mac.auto;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private TextView txtShizukuStatus;
    private TextView txtPermissionStatus;
    private Button btnGrantPermissions;
    private Button btnLaunchFloat;

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView makeText(String text, int sp, String color, int bottomDp) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(Color.parseColor(color));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(bottomDp);
        t.setLayoutParams(lp);
        return t;
    }

    private Button makeButton(String text, String bg, String fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.parseColor(fg));
        b.setBackgroundColor(Color.parseColor(bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(48));
        lp.bottomMargin = dp(12);
        b.setLayoutParams(lp);
        return b;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.parseColor("#121212"));
        root.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = makeText("MacroAutoma", 28, "#FFFFFF", 8);
        TextView subtitle = makeText("Instagram Emoji Ping Pong Automation", 14, "#AAAAAA", 32);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.parseColor("#1E1E1E"));
        card.setPadding(dp(16), dp(16), dp(16), dp(16));
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.bottomMargin = dp(24);
        card.setLayoutParams(cardLp);

        txtShizukuStatus = makeText("Shizuku Status: Checking...", 16, "#FFA500", 12);
        txtPermissionStatus = makeText("Permissions: Not Granted", 16, "#FF5252", 0);
        card.addView(txtShizukuStatus);
        card.addView(txtPermissionStatus);

        btnGrantPermissions = makeButton("Grant Overlay Permission", "#6200EE", "#FFFFFF");
        btnLaunchFloat = makeButton("Start Floating Menu", "#03DAC6", "#000000");

        root.addView(title);
        root.addView(subtitle);
        root.addView(card);
        root.addView(btnGrantPermissions);
        root.addView(btnLaunchFloat);
        setContentView(root);

        btnGrantPermissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName()));
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Overlay permission already granted!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnLaunchFloat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "Grant overlay permission first", Toast.LENGTH_SHORT).show();
                    return;
                }
                startService(new Intent(MainActivity.this, FloatingService.class));
                Toast.makeText(MainActivity.this, "Floating service launched!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        checkStatuses();
    }

    private void checkStatuses() {
        boolean overlayGranted = Settings.canDrawOverlays(this);
        boolean shizukuActive = isShizukuActive();

        txtPermissionStatus.setText("Overlay Granted: " + overlayGranted);
        txtShizukuStatus.setText("Shizuku Active: " + shizukuActive);
        btnLaunchFloat.setEnabled(overlayGranted);
    }

    // Reflection, so no Shizuku library is needed to compile.
    private boolean isShizukuActive() {
        try {
            Class<?> c = Class.forName("rikka.shizuku.Shizuku");
            boolean ping = ((Boolean) c.getMethod("pingBinder").invoke(null)).booleanValue();
            if (!ping) return false;
            int perm = ((Integer) c.getMethod("checkSelfPermission").invoke(null)).intValue();
            return perm == android.content.pm.PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }
}
