package com.mac.auto;

import android.animation.ValueAnimator;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {

    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private WindowManager wm;
    private SharedPreferences prefs;
    private Handler handler;
    private int overlayType;

    private LinearLayout root;
    private WindowManager.LayoutParams rootParams;
    private IconView bubble;
    private LinearLayout menu;
    private IconView playIcon;
    private TextView playLabel;
    private boolean menuOpen = false;
    private int restoreX = -1;
    private int restoreY = -1;

    private TextView chip;
    private WindowManager.LayoutParams chipParams;
    private boolean chipShown = false;
    private long chipHideAt = 0;

    private SetupOverlay setup;
    private boolean uiPlaying = false;
    private boolean snapping = false;

    private int sw;
    private int sh;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(float v) {
        return Ui.dp(this, v);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("macro", MODE_PRIVATE);
        handler = new Handler(Looper.getMainLooper());
        overlayType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        sw = getResources().getDisplayMetrics().widthPixels;
        sh = getResources().getDisplayMetrics().heightPixels;
        if (ScreenTrackerService.screenW > 0) {
            sw = ScreenTrackerService.screenW;
            sh = ScreenTrackerService.screenH;
        }
        buildBubble();
        buildChip();
        handler.post(poll);
    }

    // ---------- bubble + menu ----------

    private LinearLayout menuRow(IconView icon, TextView label, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(WRAP, WRAP);
        rp.topMargin = dp(6);
        row.setLayoutParams(rp);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(48), dp(48)));
        row.addView(icon);
        label.setLayoutParams(new LinearLayout.LayoutParams(WRAP, WRAP));
        row.addView(label);
        row.setOnClickListener(l);
        icon.setOnClickListener(l);
        return row;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Ui.TEXT);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setPadding(dp(12), dp(6), dp(12), dp(6));
        t.setBackground(Ui.rounded(this, Ui.alpha(Ui.CARD, 235), 14, Ui.CARD_STROKE, 1));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.leftMargin = dp(4);
        t.setLayoutParams(lp);
        return t;
    }

    private void buildBubble() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        bubble = new IconView(this, IconView.LOGO);
        bubble.setLayoutParams(new LinearLayout.LayoutParams(dp(58), dp(58)));
        bubble.setAlpha(0.92f);

        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setVisibility(View.GONE);

        IconView traceIcon = new IconView(this, IconView.TRACE);
        menu.addView(menuRow(traceIcon, label("Trace Map"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSetup(SetupOverlay.TRACE);
            }
        }));
        IconView screenIcon = new IconView(this, IconView.TARGET);
        menu.addView(menuRow(screenIcon, label("Set Screen"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSetup(SetupOverlay.TARGET);
            }
        }));
        IconView testIcon = new IconView(this, IconView.TRACE);
        menu.addView(menuRow(testIcon, label("Test swipe"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                runTest();
            }
        }));
        playIcon = new IconView(this, IconView.PLAY);
        playLabel = label("Play");
        menu.addView(menuRow(playIcon, playLabel, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlay();
            }
        }));
        IconView closeIcon = new IconView(this, IconView.CLOSE);
        menu.addView(menuRow(closeIcon, label("Close"), new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ScreenTrackerService.stopPlay();
                Intent i = new Intent(FloatingService.this, ScreenTrackerService.class);
                i.setAction(ScreenTrackerService.ACTION_STOP);
                startService(i);
                stopSelf();
            }
        }));

        root.addView(bubble);
        root.addView(menu);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float touchX;
            private float touchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) {
                    startX = rootParams.x;
                    startY = rootParams.y;
                    touchX = e.getRawX();
                    touchY = e.getRawY();
                    moved = false;
                    bubble.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
                    return true;
                }
                if (a == MotionEvent.ACTION_MOVE) {
                    float dx = e.getRawX() - touchX;
                    float dy = e.getRawY() - touchY;
                    if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                        moved = true;
                    }
                    if (moved) {
                        rootParams.x = startX + (int) dx;
                        rootParams.y = startY + (int) dy;
                        wm.updateViewLayout(root, rootParams);
                    }
                    return true;
                }
                if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    bubble.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                    if (moved) {
                        snapToEdge();
                    } else if (a == MotionEvent.ACTION_UP) {
                        onBubbleTap();
                    }
                    return true;
                }
                return false;
            }
        });

        rootParams = new WindowManager.LayoutParams(
                WRAP, WRAP, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        rootParams.gravity = Gravity.TOP | Gravity.START;
        rootParams.x = prefs.getInt("bubX", sw - dp(66));
        rootParams.y = prefs.getInt("bubY", dp(220));
        wm.addView(root, rootParams);
    }

    private void snapToEdge() {
        int from = rootParams.x;
        int to = (rootParams.x + dp(29) < sw / 2) ? dp(6) : sw - dp(64);
        int maxY = sh - dp(120);
        if (rootParams.y > maxY) {
            rootParams.y = maxY;
        }
        if (rootParams.y < dp(30)) {
            rootParams.y = dp(30);
        }
        ValueAnimator va = ValueAnimator.ofInt(from, to);
        va.setDuration(220);
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                rootParams.x = ((Integer) a.getAnimatedValue()).intValue();
                try {
                    wm.updateViewLayout(root, rootParams);
                } catch (Exception e) {
                    // view gone
                }
            }
        });
        va.start();
        prefs.edit().putInt("bubX", to).putInt("bubY", rootParams.y).apply();
    }

    private void onBubbleTap() {
        if (uiPlaying) {
            stopPlaying();
            return;
        }
        if (menuOpen) {
            closeMenu();
        } else {
            openMenu();
        }
    }

    private void openMenu() {
        menuOpen = true;
        restoreX = rootParams.x;
        restoreY = rootParams.y;
        menu.setVisibility(View.VISIBLE);
        int rowW = dp(180);
        int menuH = dp(5 * 54 + 8);
        if (rootParams.x > sw - rowW) {
            rootParams.x = sw - rowW;
        }
        if (rootParams.y + dp(58) + menuH > sh - dp(40)) {
            rootParams.y = sh - dp(58) - menuH - dp(40);
        }
        wm.updateViewLayout(root, rootParams);
        for (int i = 0; i < menu.getChildCount(); i++) {
            View row = menu.getChildAt(i);
            row.setAlpha(0f);
            row.setTranslationY(-dp(14));
            row.animate().alpha(1f).translationY(0).setStartDelay(i * 35L).setDuration(160).start();
        }
    }

    private void closeMenu() {
        if (!menuOpen) {
            return;
        }
        menuOpen = false;
        menu.setVisibility(View.GONE);
        if (restoreX >= 0) {
            rootParams.x = restoreX;
            rootParams.y = restoreY;
        }
        try {
            wm.updateViewLayout(root, rootParams);
        } catch (Exception e) {
            // ignore
        }
    }

    // ---------- status chip ----------

    private void buildChip() {
        chip = new TextView(this);
        chip.setTextColor(Ui.TEXT);
        chip.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        chip.setPadding(dp(16), dp(8), dp(16), dp(8));
        chip.setBackground(Ui.rounded(this, Ui.alpha(Ui.CARD, 240), 20, Ui.CARD_STROKE, 1));
        chipParams = new WindowManager.LayoutParams(
                WRAP, WRAP, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        chipParams.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        chipParams.y = dp(36);
    }

    private void chip(String text, int color, long ms) {
        chip.setText("\u25CF  " + text);
        chip.setMaxWidth(sw - dp(32));
        chip.setTextColor(color);
        if (!chipShown) {
            chipShown = true;
            try {
                wm.addView(chip, chipParams);
            } catch (Exception e) {
                chipShown = false;
            }
        }
        chipHideAt = ms > 0 ? System.currentTimeMillis() + ms : 0;
    }

    private void hideChip() {
        if (chipShown) {
            try {
                wm.removeView(chip);
            } catch (Exception e) {
                // ignore
            }
            chipShown = false;
        }
    }

    // ---------- live poll ----------

    private Runnable poll = new Runnable() {
        @Override
        public void run() {
            int st = Sh.state();
            if (!uiPlaying) {
                bubble.setRing(st == 2 ? Ui.GOOD : Ui.WARN);
            }
            if (uiPlaying && !ScreenTrackerService.playing) {
                uiPlaying = false;
                setPlayUi(false);
                if (st != 2) {
                    chip("Shizuku stopped - start it, then press Play", Ui.WARN, 4000);
                }
            }
            if (uiPlaying) {
                String s = ScreenTrackerService.status;
                chip(s + "\n" + ScreenTrackerService.debug, "Tracking".equals(s) ? Ui.GOOD : Ui.ACCENT2, 0);
            } else if (chipShown && chipHideAt > 0 && System.currentTimeMillis() > chipHideAt) {
                hideChip();
            }
            int[] r = new int[2];
            bubble.getLocationOnScreen(r);
            ScreenTrackerService.ignore = new int[] {
                    r[0] - dp(14), r[1] - dp(14), r[0] + dp(72), r[1] + dp(72)};
            handler.postDelayed(this, 350);
        }
    };

    // ---------- play ----------

    private void setPlayUi(boolean on) {
        if (on) {
            bubble.setType(IconView.STOP);
            bubble.setRing(Ui.BAD);
            playIcon.setType(IconView.STOP);
            playLabel.setText("Stop");
        } else {
            bubble.setType(IconView.LOGO);
            playIcon.setType(IconView.PLAY);
            playLabel.setText("Play");
            hideChipIfIdle();
        }
    }

    private void hideChipIfIdle() {
        chipHideAt = System.currentTimeMillis() + 1200;
    }

    private void togglePlay() {
        if (uiPlaying) {
            stopPlaying();
            return;
        }
        int st = Sh.state();
        if (st == 0) {
            closeMenu();
            chip("Shizuku is not running - start it first", Ui.WARN, 3500);
            return;
        }
        if (st == 1) {
            closeMenu();
            chip("Open MacroAutoma and allow Shizuku", Ui.WARN, 3500);
            return;
        }
        if (!ScreenTrackerService.ready) {
            closeMenu();
            chip("Screen capture is off - open MacroAutoma", Ui.WARN, 3500);
            return;
        }
        if (!prefs.getBoolean("traceSaved", false)) {
            closeMenu();
            chip("Set the Trace Map first", Ui.WARN, 3000);
            return;
        }
        closeMenu();
        if (ScreenTrackerService.startPlay()) {
            uiPlaying = true;
            setPlayUi(true);
        } else {
            chip(ScreenTrackerService.status, Ui.BAD, 3000);
        }
    }

    private void runTest() {
        closeMenu();
        if (Sh.state() != 2) {
            chip("Shizuku is not ready", Ui.WARN, 3000);
            return;
        }
        final int l = (int) prefs.getFloat("tLeft", sw * 0.1f);
        final int r = (int) prefs.getFloat("tRight", sw * 0.9f);
        final int y = (int) prefs.getFloat("tY", sh * 0.88f);
        final int red = (int) prefs.getFloat("tRed", sw * 0.5f);
        chip("Testing swipe...", Ui.ACCENT2, 0);
        new Thread(new Runnable() {
            @Override
            public void run() {
                final String res = Sh.testSwipe(red, l, r, y);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        chip(res, Ui.TEXT, 9000);
                    }
                });
            }
        }).start();
    }

    private void stopPlaying() {
        ScreenTrackerService.stopPlay();
        uiPlaying = false;
        setPlayUi(false);
        chip("Stopped", Ui.SUB, 1500);
    }

    // ---------- setup overlays ----------

    private WindowManager.LayoutParams fullParams() {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    private void openSetup(final int mode) {
        if (setup != null || snapping) {
            return;
        }
        closeMenu();
        if (!ScreenTrackerService.ready) {
            buildSetup(mode, null);
            Toast.makeText(this, "Screen capture is off - auto-detect needs it", Toast.LENGTH_LONG).show();
            return;
        }
        snapping = true;
        root.setVisibility(View.INVISIBLE);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                ScreenTrackerService.snapshot(new ScreenTrackerService.SnapCallback() {
                    @Override
                    public void onSnap(Bitmap b) {
                        snapping = false;
                        buildSetup(mode, b);
                    }
                });
            }
        }, 260);
    }

    private TextView pill(String text, int color, boolean filled, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        t.setGravity(Gravity.CENTER);
        t.setTextColor(filled ? 0xFF0B0D12 : Ui.TEXT);
        t.setPadding(dp(22), dp(13), dp(22), dp(13));
        if (filled) {
            t.setBackground(Ui.rounded(this, color, 26, 0, 0));
        } else {
            t.setBackground(Ui.rounded(this, Ui.alpha(Ui.CARD, 235), 26, color, 1.5f));
        }
        t.setOnClickListener(l);
        return t;
    }

    private void buildSetup(final int mode, Bitmap frozen) {
        final SetupOverlay o = new SetupOverlay(this, mode, sw, sh);
        o.frozen = frozen;
        if (mode == SetupOverlay.TRACE) {
            if (prefs.getBoolean("traceSaved", false)) {
                o.lx = prefs.getFloat("tLeft", sw * 0.1f);
                o.rx = prefs.getFloat("tRight", sw * 0.9f);
                o.ly = prefs.getFloat("tY", sh * 0.9f);
                o.redX = prefs.getFloat("tRed", sw * 0.5f);
            } else {
                o.lx = sw * 0.1f;
                o.rx = sw * 0.9f;
                o.ly = sh * 0.88f;
                o.redX = sw * 0.5f;
                autoTrace(o, false);
            }
        } else {
            o.gx = prefs.getFloat("gX", sw * 0.5f);
            o.gy = prefs.getFloat("gY", sh * 0.45f);
            autoTarget(o, false);
        }

        String hintText = mode == SetupOverlay.TRACE
                ? "Screen frozen. Drag the blue dots to the slider ends, the red dot onto the paddle."
                : "Screen frozen. Tap or drag the green dot onto the emoji ball.";
        TextView hint = new TextView(this);
        hint.setText(hintText);
        hint.setTextColor(Ui.TEXT);
        hint.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(dp(18), dp(12), dp(18), dp(12));
        hint.setBackground(Ui.rounded(this, Ui.alpha(Ui.CARD, 240), 18, Ui.CARD_STROKE, 1));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        hp.topMargin = dp(60);
        hp.leftMargin = dp(24);
        hp.rightMargin = dp(24);
        hint.setLayoutParams(hp);
        o.addView(hint);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bp.bottomMargin = dp(48);
        bar.setLayoutParams(bp);

        TextView cancel = pill("Cancel", Ui.SUB, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeSetup();
            }
        });
        TextView auto = pill("Auto detect", Ui.ACCENT2, false, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mode == SetupOverlay.TRACE) {
                    autoTrace(o, true);
                } else {
                    autoTarget(o, true);
                }
                o.invalidate();
            }
        });
        TextView save = pill("Save", Ui.GOOD, true, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveSetup(o);
                closeSetup();
                chip("Saved", Ui.GOOD, 1500);
            }
        });
        LinearLayout.LayoutParams gap = new LinearLayout.LayoutParams(WRAP, WRAP);
        gap.leftMargin = dp(10);
        auto.setLayoutParams(gap);
        LinearLayout.LayoutParams gap2 = new LinearLayout.LayoutParams(WRAP, WRAP);
        gap2.leftMargin = dp(10);
        save.setLayoutParams(gap2);
        bar.addView(cancel);
        bar.addView(auto);
        bar.addView(save);
        o.addView(bar);

        setup = o;
        o.setAlpha(0f);
        wm.addView(o, fullParams());
        o.animate().alpha(1f).setDuration(180).start();
    }

    private void autoTrace(SetupOverlay o, boolean toast) {
        if (o.frozen == null) {
            if (toast) {
                Toast.makeText(this, "No frozen screen to scan", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        Grid g = Grid.fromBitmap(o.frozen, 5, sw, sh);
        Detector.Blob p = Detector.findPaddle(g);
        if (p == null) {
            if (toast) {
                Toast.makeText(this, "Couldn't find the black paddle - place the dots by hand", Toast.LENGTH_LONG).show();
            }
            return;
        }
        float half = p.w / 2f;
        o.ly = p.cy;
        o.redX = p.cx;
        o.lx = half;
        o.rx = sw - half;
    }

    private void autoTarget(SetupOverlay o, boolean toast) {
        if (o.frozen == null) {
            if (toast) {
                Toast.makeText(this, "No frozen screen to scan", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        Grid g = Grid.fromBitmap(o.frozen, 5, sw, sh);
        float lineY = prefs.getBoolean("traceSaved", false) ? prefs.getFloat("tY", sh * 0.88f) : sh * 0.88f;
        Detector.Blob pd = Detector.findPaddle(g);
        if (pd != null) {
            lineY = pd.cy;
        }
        int bg = Detector.background(g);
        Detector.Blob[] bl = Detector.blobs(g, Detector.MODE_BG, bg, 110, (int) (sh * 0.20f), (int) (lineY - sh * 0.03f));
        Detector.Blob pick = Detector.pickBall(bl, 0, 0, sw);
        if (pick == null) {
            o.found = null;
            if (toast) {
                Toast.makeText(this, "Emoji not visible in this frame - drag the green dot onto it", Toast.LENGTH_LONG).show();
            }
            return;
        }
        o.gx = pick.cx;
        o.gy = pick.cy;
        o.found = new RectF(pick.minX, pick.minY, pick.maxX, pick.maxY);
    }

    private void saveSetup(SetupOverlay o) {
        SharedPreferences.Editor ed = prefs.edit();
        if (o.mode == SetupOverlay.TRACE) {
            ed.putBoolean("traceSaved", true);
            ed.putFloat("tLeft", o.lx);
            ed.putFloat("tRight", o.rx);
            ed.putFloat("tY", o.ly);
            ed.putFloat("tRed", o.redX);
        } else {
            ed.putFloat("gX", o.gx);
            ed.putFloat("gY", o.gy);
            int ew = 0;
            int eh = 0;
            int ed2 = 0;
            if (o.frozen != null) {
                Grid g = Grid.fromBitmap(o.frozen, 5, sw, sh);
                int bg = Detector.background(g);
                Detector.Blob[] bl = Detector.blobs(g, Detector.MODE_BG, bg, 110, (int) (sh * 0.1f), (int) (sh * 0.95f));
                Detector.Blob near = null;
                float best = dp(60);
                for (int i = 0; i < bl.length; i++) {
                    float dx = bl[i].cx - o.gx;
                    float dy = bl[i].cy - o.gy;
                    float d = (float) Math.sqrt(dx * dx + dy * dy);
                    if (d < best) {
                        best = d;
                        near = bl[i];
                    }
                }
                if (near != null) {
                    ew = near.w;
                    eh = near.h;
                    ed2 = (int) near.meanDist;
                }
            }
            ed.putInt("ew", ew);
            ed.putInt("eh", eh);
            ed.putInt("edist", ed2);
        }
        ed.apply();
    }

    private void closeSetup() {
        if (setup != null) {
            try {
                wm.removeView(setup);
            } catch (Exception e) {
                // ignore
            }
            setup = null;
        }
        root.setVisibility(View.VISIBLE);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(poll);
        closeSetup();
        hideChip();
        if (root != null) {
            try {
                wm.removeView(root);
            } catch (Exception e) {
                // ignore
            }
            root = null;
        }
        super.onDestroy();
    }
}
