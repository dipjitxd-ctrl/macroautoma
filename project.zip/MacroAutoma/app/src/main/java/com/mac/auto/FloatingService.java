// ===== GITHUB BUILD V2 - bubble + draggable overlays =====
package com.mac.auto;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class FloatingService extends Service {

    private static final int WRAP = LinearLayout.LayoutParams.WRAP_CONTENT;

    private WindowManager wm;
    private SharedPreferences prefs;
    private int overlayType;

    private LinearLayout root;
    private WindowManager.LayoutParams rootParams;
    private LinearLayout menu;
    private Button btnPlay;
    private boolean playing = false;

    private TraceLayout traceView;
    private FrameLayout screenView;

    // Draws the blue line between the two blue balls
    private static class TraceLayout extends FrameLayout {
        View left;
        View right;
        Paint paint = new Paint();

        TraceLayout(Context c) {
            super(c);
            setWillNotDraw(false);
            paint.setColor(Color.parseColor("#2196F3"));
            paint.setStrokeWidth(8f);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (left != null && right != null) {
                canvas.drawLine(
                        left.getX() + left.getWidth() / 2f, left.getY() + left.getHeight() / 2f,
                        right.getX() + right.getWidth() / 2f, right.getY() + right.getHeight() / 2f,
                        paint);
            }
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int screenW() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    private int screenH() {
        return getResources().getDisplayMetrics().heightPixels;
    }

    private GradientDrawable oval(int color) {
        GradientDrawable d = new GradientDrawable();
        d.setShape(GradientDrawable.OVAL);
        d.setColor(color);
        return d;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences("macro", MODE_PRIVATE);
        overlayType = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        buildFloating();
    }

    // ---------- floating bubble + menu ----------

    private Button menuButton(String text, String color, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor(color));
        b.setAllCaps(false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(100), dp(36));
        lp.bottomMargin = dp(4);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private void buildFloating() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        TextView bubble = new TextView(this);
        bubble.setText("M");
        bubble.setTextColor(Color.WHITE);
        bubble.setTextSize(18);
        bubble.setGravity(Gravity.CENTER);
        bubble.setBackground(oval(Color.parseColor("#E91E63")));
        bubble.setLayoutParams(new LinearLayout.LayoutParams(dp(52), dp(52)));

        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setBackgroundColor(Color.parseColor("#DD212121"));
        menu.setPadding(dp(6), dp(6), dp(6), dp(2));
        menu.setVisibility(View.GONE);
        LinearLayout.LayoutParams menuLp = new LinearLayout.LayoutParams(WRAP, WRAP);
        menuLp.topMargin = dp(6);
        menu.setLayoutParams(menuLp);

        menu.addView(menuButton("Trace Map", "#333333", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTrace();
            }
        }));
        menu.addView(menuButton("Set Screen", "#333333", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showScreen();
            }
        }));
        btnPlay = menuButton("Play", "#4CAF50", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePlay();
            }
        });
        menu.addView(btnPlay);
        menu.addView(menuButton("Close app", "#B71C1C", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        }));

        root.addView(bubble);
        root.addView(menu);

        bubble.setOnTouchListener(new View.OnTouchListener() {
            private int startX;
            private int startY;
            private float touchX;
            private float touchY;
            private boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startX = rootParams.x;
                        startY = rootParams.y;
                        touchX = e.getRawX();
                        touchY = e.getRawY();
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = e.getRawX() - touchX;
                        float dy = e.getRawY() - touchY;
                        if (Math.abs(dx) > dp(6) || Math.abs(dy) > dp(6)) {
                            moved = true;
                        }
                        if (moved) {
                            rootParams.x = startX + (int) dx;
                            rootParams.y = startY + (int) dy;
                            wm.updateViewLayout(root, rootParams);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) {
                            toggleMenu();
                        }
                        return true;
                }
                return false;
            }
        });

        rootParams = new WindowManager.LayoutParams(
                WRAP, WRAP, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        rootParams.gravity = Gravity.TOP | Gravity.START;
        rootParams.x = dp(16);
        rootParams.y = dp(200);
        wm.addView(root, rootParams);
    }

    private void toggleMenu() {
        menu.setVisibility(menu.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
        wm.updateViewLayout(root, rootParams);
    }

    private void togglePlay() {
        playing = !playing;
        btnPlay.setText(playing ? "Stop" : "Play");
        btnPlay.setBackgroundColor(Color.parseColor(playing ? "#F44336" : "#4CAF50"));
        if (playing) {
            Toast.makeText(this, "Play ON (tap/ball logic not written yet)", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Play OFF", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------- overlays ----------

    private WindowManager.LayoutParams fullParams() {
        return new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
    }

    private View makeBall(String colorHex, int sizeDp, String key, float defX, float defY, final View parent) {
        View b = new View(this);
        b.setBackground(oval(Color.parseColor(colorHex)));
        b.setLayoutParams(new FrameLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        b.setX(prefs.getFloat(key + "X", defX));
        b.setY(prefs.getFloat(key + "Y", defY));
        b.setOnTouchListener(new View.OnTouchListener() {
            private float dX;
            private float dY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        dX = v.getX() - e.getRawX();
                        dY = v.getY() - e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        v.setX(e.getRawX() + dX);
                        v.setY(e.getRawY() + dY);
                        parent.invalidate();
                        return true;
                }
                return false;
            }
        });
        return b;
    }

    private TextView hint(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundColor(Color.parseColor("#99000000"));
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        lp.topMargin = dp(90);
        t.setLayoutParams(lp);
        return t;
    }

    private Button overlayButton(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor("#6200EE"));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        lp.bottomMargin = dp(80);
        b.setLayoutParams(lp);
        b.setOnClickListener(l);
        return b;
    }

    private void saveBall(String key, View b) {
        prefs.edit().putFloat(key + "X", b.getX()).putFloat(key + "Y", b.getY()).apply();
    }

    private void showTrace() {
        if (traceView != null || screenView != null) return;
        final TraceLayout layout = new TraceLayout(this);
        layout.setBackgroundColor(Color.parseColor("#66000000"));
        int w = screenW();
        int h = screenH();
        final View left = makeBall("#2196F3", 40, "left", w * 0.15f, h * 0.5f, layout);
        final View right = makeBall("#2196F3", 40, "right", w * 0.75f, h * 0.5f, layout);
        final View red = makeBall("#FF5252", 40, "red", w * 0.45f, h * 0.5f, layout);
        layout.left = left;
        layout.right = right;
        layout.addView(left);
        layout.addView(right);
        layout.addView(red);
        layout.addView(hint("Drag the blue balls to the ends of the paddle line, and the red ball to the paddle"));
        layout.addView(overlayButton("Save & Close", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveBall("left", left);
                saveBall("right", right);
                saveBall("red", red);
                closeOverlays();
                Toast.makeText(FloatingService.this, "Trace saved", Toast.LENGTH_SHORT).show();
            }
        }));
        traceView = layout;
        root.setVisibility(View.GONE);
        wm.addView(layout, fullParams());
    }

    private void showScreen() {
        if (traceView != null || screenView != null) return;
        final FrameLayout layout = new FrameLayout(this);
        layout.setBackgroundColor(Color.parseColor("#66000000"));
        final View green = makeBall("#4CAF50", 48, "green", screenW() * 0.5f - dp(24), screenH() * 0.5f, layout);
        layout.addView(green);
        layout.addView(hint("Drag the green ball onto the target spot"));
        layout.addView(overlayButton("Confirm Target & Close", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveBall("green", green);
                closeOverlays();
                Toast.makeText(FloatingService.this, "Target saved", Toast.LENGTH_SHORT).show();
            }
        }));
        screenView = layout;
        root.setVisibility(View.GONE);
        wm.addView(layout, fullParams());
    }

    private void closeOverlays() {
        try {
            if (traceView != null) {
                wm.removeView(traceView);
            }
            if (screenView != null) {
                wm.removeView(screenView);
            }
        } catch (Exception e) {
            // already removed
        }
        traceView = null;
        screenView = null;
        if (root != null) {
            root.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        closeOverlays();
        if (root != null) {
            try {
                wm.removeView(root);
            } catch (Exception e) {
                // already removed
            }
            root = null;
        }
    }
}
