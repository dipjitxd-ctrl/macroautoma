// ===== GITHUB BUILD - UI built in code, no R needed =====
package com.mac.auto;

import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class FloatingService extends Service {

    private WindowManager windowManager;
    private LinearLayout floatView;
    private WindowManager.LayoutParams floatParams;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private Button makeButton(final String label, String bg, boolean last) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.parseColor(bg));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(120), dp(40));
        if (!last) lp.bottomMargin = dp(6);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(FloatingService.this, label, Toast.LENGTH_SHORT).show();
            }
        });
        return b;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        floatView = new LinearLayout(this);
        floatView.setOrientation(LinearLayout.VERTICAL);
        floatView.setGravity(Gravity.CENTER);
        floatView.setBackgroundColor(Color.parseColor("#DD212121"));
        floatView.setPadding(dp(8), dp(8), dp(8), dp(8));

        floatView.addView(makeButton("Trace Map", "#333333", false));
        floatView.addView(makeButton("Set Screen", "#333333", false));
        floatView.addView(makeButton("Play", "#4CAF50", true));

        floatParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);

        floatParams.gravity = Gravity.TOP | Gravity.START;
        floatParams.x = 100;
        floatParams.y = 100;

        windowManager.addView(floatView, floatParams);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatView != null) {
            windowManager.removeView(floatView);
            floatView = null;
        }
    }
}
