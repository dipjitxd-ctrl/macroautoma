package com.mac.auto;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.nio.ByteBuffer;

public class ScreenTrackerService extends Service {

    public static final String ACTION_INIT = "com.mac.auto.INIT";
    public static final String ACTION_STOP = "com.mac.auto.STOP";
    public static final String CHANNEL = "macro_capture";
    private static final int STEP = 5;

    public static volatile boolean ready = false;
    public static volatile boolean playing = false;
    public static volatile String status = "Idle";
    public static volatile String debug = "";
    public static volatile Runnable onAutoStop = null;
    public static volatile int[] ignore = null;
    public static int screenW = 0;
    public static int screenH = 0;

    public interface SnapCallback {
        void onSnap(Bitmap b);
    }

    private static ScreenTrackerService inst;

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler handler;
    private Handler main;

    private Bitmap store;
    private long lastStore = 0;
    private volatile SnapCallback pendingSnap;

    // play state
    private float left;
    private float right;
    private float lineY;
    private int ew;
    private int eh;
    private int edist;
    private volatile int curX;
    private volatile int pendingTarget = -1;
    private Thread worker;
    private volatile boolean workerRun = false;
    private long[] ht = new long[8];
    private float[] hx = new float[8];
    private float[] hy = new float[8];
    private int hn = 0;
    private int lost = 0;
    private long lastShizukuCheck = 0;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        inst = this;
        main = new Handler(Looper.getMainLooper());
        thread = new HandlerThread("macro-capture");
        thread.start();
        handler = new Handler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) {
            return START_NOT_STICKY;
        }
        String a = intent.getAction();
        if (ACTION_STOP.equals(a)) {
            teardown();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        if (ACTION_INIT.equals(a)) {
            startFg();
            int rc = intent.getIntExtra("rc", 0);
            Intent data = (Intent) intent.getParcelableExtra("data");
            if (data != null) {
                setup(rc, data);
            }
        }
        return START_NOT_STICKY;
    }

    private void startFg() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder nb;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Screen reading", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            nb = new Notification.Builder(this, CHANNEL);
        } else {
            nb = new Notification.Builder(this);
        }
        nb.setContentTitle("MacroAutoma");
        nb.setContentText("Screen reading is active");
        nb.setSmallIcon(android.R.drawable.ic_media_play);
        Notification n = nb.build();
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
        } else {
            startForeground(7, n);
        }
    }

    private void setup(int rc, Intent data) {
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(rc, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    ready = false;
                    playing = false;
                }
            }, handler);
            DisplayMetrics dm = new DisplayMetrics();
            WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            wm.getDefaultDisplay().getRealMetrics(dm);
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            reader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 2);
            vd = projection.createVirtualDisplay("macro", screenW, screenH, dm.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, handler);
            reader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
                @Override
                public void onImageAvailable(ImageReader r) {
                    onFrame(r);
                }
            }, handler);
            ready = true;
            status = "Ready";
        } catch (Throwable t) {
            ready = false;
            status = "Capture failed";
        }
    }

    // ---------- frames ----------

    private void onFrame(ImageReader r) {
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) {
                return;
            }
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer b = p.getBuffer();
            int rowStride = p.getRowStride();
            int pixStride = p.getPixelStride();
            long now = SystemClock.uptimeMillis();

            boolean needStore = pendingSnap != null || (!playing && now - lastStore > 350);
            if (needStore) {
                int bw = rowStride / pixStride;
                if (store == null || store.getWidth() != bw || store.getHeight() != img.getHeight()) {
                    store = Bitmap.createBitmap(bw, img.getHeight(), Bitmap.Config.ARGB_8888);
                }
                b.rewind();
                store.copyPixelsFromBuffer(b);
                lastStore = now;
                SnapCallback cb = pendingSnap;
                if (cb != null) {
                    pendingSnap = null;
                    deliver(cb);
                }
            }
            if (playing) {
                Grid g = Grid.fromBuffer(b, rowStride, pixStride, img.getWidth(), img.getHeight(), STEP);
                track(g, now);
            }
        } catch (Throwable t) {
            debug = "frame error: " + t;
        } finally {
            if (img != null) {
                img.close();
            }
        }
    }

    private void deliver(final SnapCallback cb) {
        Bitmap out = null;
        try {
            if (store != null) {
                Bitmap crop = Bitmap.createBitmap(store, 0, 0, screenW, screenH);
                out = Bitmap.createScaledBitmap(crop, screenW / 2, screenH / 2, true);
                if (crop != store) {
                    crop.recycle();
                }
            }
        } catch (Throwable t) {
            out = null;
        }
        final Bitmap result = out;
        main.post(new Runnable() {
            @Override
            public void run() {
                cb.onSnap(result);
            }
        });
    }

    // Asks for a fresh frame (falls back to the newest stored one after a short wait).
    public static void snapshot(final SnapCallback cb) {
        final ScreenTrackerService s = inst;
        if (s == null || !ready) {
            cb.onSnap(null);
            return;
        }
        s.pendingSnap = cb;
        s.handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                SnapCallback c = s.pendingSnap;
                if (c != null) {
                    s.pendingSnap = null;
                    s.deliver(c);
                }
            }
        }, 450);
    }

    // ---------- play ----------

    public static boolean startPlay() {
        ScreenTrackerService s = inst;
        if (s == null || !ready) {
            return false;
        }
        return s.beginPlay();
    }

    public static void stopPlay() {
        ScreenTrackerService s = inst;
        playing = false;
        status = "Stopped";
        if (s != null) {
            s.workerRun = false;
        }
    }

    private boolean beginPlay() {
        SharedPreferences p = getSharedPreferences("macro", MODE_PRIVATE);
        if (!p.getBoolean("traceSaved", false)) {
            status = "Set Trace Map first";
            return false;
        }
        left = p.getFloat("tLeft", screenW * 0.1f);
        right = p.getFloat("tRight", screenW * 0.9f);
        lineY = p.getFloat("tY", screenH * 0.9f);
        curX = (int) p.getFloat("tRed", screenW * 0.5f);
        ew = p.getInt("ew", 0);
        eh = p.getInt("eh", 0);
        edist = p.getInt("edist", 0);
        hn = 0;
        lost = 0;
        pendingTarget = -1;
        workerRun = true;
        worker = new Thread(new Runnable() {
            @Override
            public void run() {
                workerLoop();
            }
        });
        worker.start();
        status = "Waiting for ball";
        playing = true;
        return true;
    }

    private void workerLoop() {
        while (workerRun) {
            int tg = pendingTarget;
            if (tg >= 0) {
                pendingTarget = -1;
                int from = curX;
                int dx = Math.abs(tg - from);
                if (dx > 14) {
                    int dur = (int) Math.max(35, Math.min(150, dx * 0.12f));
                    Sh.swipe(from, (int) lineY, tg, (int) lineY, dur);
                    curX = tg;
                }
            } else {
                try {
                    Thread.sleep(2);
                } catch (InterruptedException e) {
                    return;
                }
            }
        }
    }

    private void track(Grid g, long now) {
        if (now - lastShizukuCheck > 700) {
            lastShizukuCheck = now;
            if (!Sh.ready()) {
                playing = false;
                workerRun = false;
                status = "Shizuku stopped";
                Runnable r = onAutoStop;
                if (r != null) {
                    main.post(r);
                }
                return;
            }
        }
        int bg = Detector.background(g);
        int thr = 110;
        if (edist > 0) {
            thr = (int) Math.max(90, Math.min(170, edist * 0.4f));
        }
        int top = (int) (screenH * 0.20f);
        int bottom = (int) (lineY - screenH * 0.022f);
        Detector.Blob[] bl = Detector.blobs(g, Detector.MODE_BG, bg, thr, top, bottom);
        if (bl.length > 7) {
            debug = "too many blobs: " + bl.length;
            status = "Game over screen";
            hn = 0;
            return;
        }
        int[] ig = ignore;
        if (ig != null) {
            int keep = 0;
            Detector.Blob[] f = new Detector.Blob[bl.length];
            for (int i = 0; i < bl.length; i++) {
                boolean inside = bl[i].cx > ig[0] && bl[i].cx < ig[2] && bl[i].cy > ig[1] && bl[i].cy < ig[3];
                if (!inside) {
                    f[keep++] = bl[i];
                }
            }
            Detector.Blob[] f2 = new Detector.Blob[keep];
            for (int i = 0; i < keep; i++) {
                f2[i] = f[i];
            }
            bl = f2;
        }
        Detector.Blob ball = Detector.pickBall(bl, ew, eh, screenW);
        if (ball == null) {
            debug = "no ball | blobs " + bl.length + " thr " + thr + " ref " + ew + "x" + eh;
            lost++;
            if (lost > 12) {
                hn = 0;
                status = "Waiting for ball";
            }
            return;
        }
        lost = 0;
        debug = "ball " + (int) ball.cx + "," + (int) ball.cy + " size " + ball.w + "x" + ball.h
                + " | sent " + Sh.sent + (Sh.lastError.length() > 0 ? " | " + Sh.lastError : "");
        // reject teleports
        if (hn > 0) {
            float jx = Math.abs(ball.cx - hx[hn - 1]);
            float jy = Math.abs(ball.cy - hy[hn - 1]);
            if (jx > screenW * 0.4f || jy > screenH * 0.3f) {
                hn = 0;
            }
        }
        if (hn == ht.length) {
            for (int i = 1; i < hn; i++) {
                ht[i - 1] = ht[i];
                hx[i - 1] = hx[i];
                hy[i - 1] = hy[i];
            }
            hn--;
        }
        ht[hn] = now;
        hx[hn] = ball.cx;
        hy[hn] = ball.cy;
        hn++;
        // drop old samples
        while (hn > 3 && now - ht[0] > 220) {
            for (int i = 1; i < hn; i++) {
                ht[i - 1] = ht[i];
                hx[i - 1] = hx[i];
                hy[i - 1] = hy[i];
            }
            hn--;
        }
        if (hn < 3) {
            status = "Tracking";
            return;
        }
        // least squares velocity
        double mt = 0;
        double mx = 0;
        double my = 0;
        for (int i = 0; i < hn; i++) {
            mt += ht[i];
            mx += hx[i];
            my += hy[i];
        }
        mt /= hn;
        mx /= hn;
        my /= hn;
        double den = 0;
        double nx = 0;
        double ny = 0;
        for (int i = 0; i < hn; i++) {
            double dt = ht[i] - mt;
            den += dt * dt;
            nx += dt * (hx[i] - mx);
            ny += dt * (hy[i] - my);
        }
        if (den < 1) {
            return;
        }
        float vx = (float) (nx / den);
        float vy = (float) (ny / den);
        float cx = hx[hn - 1];
        float cy = hy[hn - 1];
        if (vy < 0.08f) {
            status = "Ball going up";
            return;
        }
        float radius = Math.max(ball.w, ball.h) / 2f;
        float t = (lineY - radius - cy) / vy;
        if (t < 0) {
            t = 0;
        }
        float xp = cx + vx * t;
        float rmin = radius;
        float rmax = screenW - radius;
        float span = rmax - rmin;
        if (span > 10) {
            float u = (xp - rmin) % (2 * span);
            if (u < 0) {
                u += 2 * span;
            }
            if (u > span) {
                u = 2 * span - u;
            }
            xp = rmin + u;
        }
        if (xp < left) {
            xp = left;
        }
        if (xp > right) {
            xp = right;
        }
        pendingTarget = (int) xp;
        debug = "ball " + (int) cx + "," + (int) cy + " vy " + (int) (vy * 1000) + " -> " + (int) xp
                + " | sent " + Sh.sent + (Sh.lastError.length() > 0 ? " | " + Sh.lastError : "");
        status = "Tracking";
    }

    private void teardown() {
        playing = false;
        workerRun = false;
        ready = false;
        try {
            if (vd != null) vd.release();
        } catch (Throwable t) {
            // ignore
        }
        try {
            if (reader != null) reader.close();
        } catch (Throwable t) {
            // ignore
        }
        try {
            if (projection != null) projection.stop();
        } catch (Throwable t) {
            // ignore
        }
        vd = null;
        reader = null;
        projection = null;
    }

    @Override
    public void onDestroy() {
        teardown();
        Sh.close();
        if (thread != null) {
            thread.quitSafely();
        }
        inst = null;
        super.onDestroy();
    }
}
