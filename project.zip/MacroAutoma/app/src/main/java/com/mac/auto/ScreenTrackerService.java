// ===== GITHUB BUILD - UI built in code, no R needed =====
package com.mac.auto;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class ScreenTrackerService extends Service {

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        // TODO: screen tracking logic goes here
    }
}
