package com.mac.auto;

import android.content.Context;
import android.content.SharedPreferences;

import java.io.PrintWriter;
import java.io.StringWriter;

// Saves the last crash so the main screen can show it (no adb needed).
public class Crash {

    private static boolean installed = false;

    public static synchronized void install(Context c) {
        if (installed) {
            return;
        }
        installed = true;
        final SharedPreferences sp = c.getApplicationContext().getSharedPreferences("macro", Context.MODE_PRIVATE);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    StringWriter sw = new StringWriter();
                    e.printStackTrace(new PrintWriter(sw));
                    String s = sw.toString();
                    if (s.length() > 900) {
                        s = s.substring(0, 900);
                    }
                    sp.edit().putString("lastCrash", s).commit();
                } catch (Throwable x) {
                    // ignore
                }
                if (prev != null) {
                    prev.uncaughtException(t, e);
                }
            }
        });
    }
}
